// ═══════════════════════════════════════════════════════════════════════════════
// THE FINEST GRAIN ERC1155a - TEST SUITE
// License: EXCLUSIVE PROPERTY OF ALBERT HUELLSTROUNK
// ═══════════════════════════════════════════════════════════════════════════════

const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("ERC1155a_FinestGrain", function () {
  let finestGrain;
  let owner;
  let addr1;
  let addr2;
  let addr3;

  const BASE_URI = "https://api.finestgrain.eth/metadata/";
  const CONTRACT_URI = "https://api.finestgrain.eth/contract.json";

  // Token IDs
  const IMPERIAL_GOLDEN_WHEAT = 1;
  const CELESTIAL_RICE = 2;
  const ROYAL_QUINOA = 3;

  beforeEach(async function () {
    [owner, addr1, addr2, addr3] = await ethers.getSigners();

    const ERC1155a_FinestGrain = await ethers.getContractFactory("ERC1155a_FinestGrain");
    finestGrain = await ERC1155a_FinestGrain.deploy(
      owner.address,
      BASE_URI,
      CONTRACT_URI
    );
    await finestGrain.waitForDeployment();
  });

  describe("License Information", function () {
    it("Should store correct license holder", async function () {
      expect(await finestGrain.LICENSE_HOLDER()).to.equal("ALBERT HUELLSTROUNK");
    });

    it("Should store correct license ID", async function () {
      expect(await finestGrain.LICENSE_ID()).to.equal("AH-FINEST-GRAIN-2024-EXCLUSIVE");
    });

    it("Should store correct license type", async function () {
      expect(await finestGrain.LICENSE_TYPE()).to.equal("EXCLUSIVE_PERPETUAL_IRREVOCABLE");
    });

    it("Should return full license info", async function () {
      const [holder, licenseId, licenseType, copyright, notice] = 
        await finestGrain.getFullLicenseInfo();
      
      expect(holder).to.equal("ALBERT HUELLSTROUNK");
      expect(licenseId).to.equal("AH-FINEST-GRAIN-2024-EXCLUSIVE");
      expect(licenseType).to.equal("EXCLUSIVE_PERPETUAL_IRREVOCABLE");
    });
  });

  describe("Role Management", function () {
    it("Should grant DEFAULT_ADMIN_ROLE to deployer", async function () {
      const DEFAULT_ADMIN_ROLE = await finestGrain.DEFAULT_ADMIN_ROLE();
      expect(await finestGrain.hasRole(DEFAULT_ADMIN_ROLE, owner.address)).to.be.true;
    });

    it("Should grant LICENSE_HOLDER_ROLE to deployer", async function () {
      const LICENSE_HOLDER_ROLE = await finestGrain.LICENSE_HOLDER_ROLE();
      expect(await finestGrain.hasRole(LICENSE_HOLDER_ROLE, owner.address)).to.be.true;
    });

    it("Should grant GRAIN_KEEPER_ROLE to deployer", async function () {
      const GRAIN_KEEPER_ROLE = await finestGrain.GRAIN_KEEPER_ROLE();
      expect(await finestGrain.hasRole(GRAIN_KEEPER_ROLE, owner.address)).to.be.true;
    });

    it("Should grant SECURITY_OFFICER_ROLE to deployer", async function () {
      const SECURITY_OFFICER_ROLE = await finestGrain.SECURITY_OFFICER_ROLE();
      expect(await finestGrain.hasRole(SECURITY_OFFICER_ROLE, owner.address)).to.be.true;
    });
  });

  describe("Whitelist Security", function () {
    it("Should whitelist deployer by default", async function () {
      expect(await finestGrain.isWhitelisted(owner.address)).to.be.true;
    });

    it("Should allow LICENSE_HOLDER to add to whitelist", async function () {
      await finestGrain.addToWhitelist(addr1.address);
      expect(await finestGrain.isWhitelisted(addr1.address)).to.be.true;
    });

    it("Should allow LICENSE_HOLDER to remove from whitelist", async function () {
      await finestGrain.addToWhitelist(addr1.address);
      await finestGrain.removeFromWhitelist(addr1.address);
      expect(await finestGrain.isWhitelisted(addr1.address)).to.be.false;
    });

    it("Should prevent non-license holders from adding to whitelist", async function () {
      await expect(
        finestGrain.connect(addr1).addToWhitelist(addr2.address)
      ).to.be.reverted;
    });
  });

  describe("Account Freezing", function () {
    it("Should allow SECURITY_OFFICER to freeze accounts", async function () {
      await finestGrain.freezeAccount(addr1.address);
      expect(await finestGrain.isFrozen(addr1.address)).to.be.true;
    });

    it("Should allow LICENSE_HOLDER to unfreeze accounts", async function () {
      await finestGrain.freezeAccount(addr1.address);
      await finestGrain.unfreezeAccount(addr1.address);
      expect(await finestGrain.isFrozen(addr1.address)).to.be.false;
    });

    it("Should prevent non-security officers from freezing", async function () {
      await expect(
        finestGrain.connect(addr1).freezeAccount(addr2.address)
      ).to.be.reverted;
    });
  });

  describe("Minting", function () {
    beforeEach(async function () {
      await finestGrain.addToWhitelist(addr1.address);
    });

    it("Should allow GRAIN_KEEPER to mint tokens", async function () {
      await finestGrain.mint(addr1.address, IMPERIAL_GOLDEN_WHEAT, 10, "0x");
      expect(await finestGrain.balanceOf(addr1.address, IMPERIAL_GOLDEN_WHEAT)).to.equal(10);
    });

    it("Should not allow minting to non-whitelisted address", async function () {
      await expect(
        finestGrain.mint(addr2.address, IMPERIAL_GOLDEN_WHEAT, 10, "0x")
      ).to.be.revertedWith("Recipient not whitelisted");
    });

    it("Should not allow minting beyond max supply", async function () {
      // Max supply for IMPERIAL_GOLDEN_WHEAT is 100
      await expect(
        finestGrain.mint(addr1.address, IMPERIAL_GOLDEN_WHEAT, 101, "0x")
      ).to.be.revertedWith("Exceeds max supply");
    });

    it("Should prevent non-grain-keepers from minting", async function () {
      await expect(
        finestGrain.connect(addr1).mint(addr1.address, IMPERIAL_GOLDEN_WHEAT, 10, "0x")
      ).to.be.reverted;
    });
  });

  describe("Transfer Security", function () {
    beforeEach(async function () {
      await finestGrain.addToWhitelist(addr1.address);
      await finestGrain.mint(addr1.address, IMPERIAL_GOLDEN_WHEAT, 10, "0x");
    });

    it("Should allow transfer to whitelisted address", async function () {
      await finestGrain.addToWhitelist(addr2.address);
      await finestGrain.connect(addr1).safeTransferFrom(
        addr1.address,
        addr2.address,
        IMPERIAL_GOLDEN_WHEAT,
        5,
        "0x"
      );
      expect(await finestGrain.balanceOf(addr2.address, IMPERIAL_GOLDEN_WHEAT)).to.equal(5);
    });

    it("Should prevent transfer to non-whitelisted address", async function () {
      await expect(
        finestGrain.connect(addr1).safeTransferFrom(
          addr1.address,
          addr2.address,
          IMPERIAL_GOLDEN_WHEAT,
          5,
          "0x"
        )
      ).to.be.revertedWith("TransferToNonWhitelistedAddress");
    });

    it("Should prevent transfer from frozen account", async function () {
      await finestGrain.addToWhitelist(addr2.address);
      await finestGrain.freezeAccount(addr1.address);
      
      await expect(
        finestGrain.connect(addr1).safeTransferFrom(
          addr1.address,
          addr2.address,
          IMPERIAL_GOLDEN_WHEAT,
          5,
          "0x"
        )
      ).to.be.revertedWith("Account is frozen");
    });
  });

  describe("Emergency Pause", function () {
    beforeEach(async function () {
      await finestGrain.addToWhitelist(addr1.address);
      await finestGrain.addToWhitelist(addr2.address);
      await finestGrain.mint(addr1.address, IMPERIAL_GOLDEN_WHEAT, 10, "0x");
    });

    it("Should allow SECURITY_OFFICER to pause", async function () {
      await finestGrain.emergencyPause();
      expect(await finestGrain.paused()).to.be.true;
    });

    it("Should prevent transfers when paused", async function () {
      await finestGrain.emergencyPause();
      
      await expect(
        finestGrain.connect(addr1).safeTransferFrom(
          addr1.address,
          addr2.address,
          IMPERIAL_GOLDEN_WHEAT,
          5,
          "0x"
        )
      ).to.be.revertedWith("Pausable: paused");
    });

    it("Should allow LICENSE_HOLDER to unpause", async function () {
      await finestGrain.emergencyPause();
      await finestGrain.resumeTransfers();
      expect(await finestGrain.paused()).to.be.false;
    });
  });

  describe("Grain Certificates", function () {
    it("Should have valid certificate for Imperial Golden Wheat", async function () {
      const [isValid, grainType, origin, purityScore] = 
        await finestGrain.verifyGrainCertificate(IMPERIAL_GOLDEN_WHEAT);
      
      expect(isValid).to.be.true;
      expect(grainType).to.equal("Imperial Golden Wheat");
      expect(origin).to.equal("Ancient Fertile Crescent, Mesopotamia");
      expect(purityScore).to.equal(9999);
    });

    it("Should have valid certificate for Celestial Rice", async function () {
      const [isValid, grainType] = await finestGrain.verifyGrainCertificate(CELESTIAL_RICE);
      expect(isValid).to.be.true;
      expect(grainType).to.equal("Celestial Rice");
    });

    it("Should have valid certificate for Royal Quinoa", async function () {
      const [isValid, grainType] = await finestGrain.verifyGrainCertificate(ROYAL_QUINOA);
      expect(isValid).to.be.true;
      expect(grainType).to.equal("Royal Quinoa");
    });
  });

  describe("Supply Management", function () {
    it("Should track total supply correctly", async function () {
      await finestGrain.addToWhitelist(addr1.address);
      await finestGrain.mint(addr1.address, IMPERIAL_GOLDEN_WHEAT, 10, "0x");
      expect(await finestGrain.totalSupply(IMPERIAL_GOLDEN_WHEAT)).to.equal(10);
    });

    it("Should have correct max supply", async function () {
      expect(await finestGrain.maxSupply(IMPERIAL_GOLDEN_WHEAT)).to.equal(100);
      expect(await finestGrain.maxSupply(CELESTIAL_RICE)).to.equal(75);
      expect(await finestGrain.maxSupply(ROYAL_QUINOA)).to.equal(50);
    });
  });

  describe("URI Management", function () {
    it("Should return correct contract URI", async function () {
      expect(await finestGrain.contractURI()).to.equal(CONTRACT_URI);
    });

    it("Should allow LICENSE_HOLDER to update contract URI", async function () {
      const newURI = "https://new-api.finestgrain.eth/contract.json";
      await finestGrain.setContractURI(newURI);
      expect(await finestGrain.contractURI()).to.equal(newURI);
    });

    it("Should allow LICENSE_HOLDER to update base URI", async function () {
      const newBaseURI = "https://new-api.finestgrain.eth/metadata/";
      await finestGrain.setBaseURI(newBaseURI);
      expect(await finestGrain.uri(IMPERIAL_GOLDEN_WHEAT)).to.equal(newBaseURI + "1");
    });
  });
});