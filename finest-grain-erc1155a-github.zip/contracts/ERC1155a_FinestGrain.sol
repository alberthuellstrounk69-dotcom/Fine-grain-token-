// SPDX-License-Identifier: LICENSE-ALBERT-HUELLSTROUNK-1.0
/*
 * ███████╗███████╗ █████╗ ██████╗ ███████╗██████╗ ███╗   ███╗ █████╗ ███████╗ ██████╗
 * ██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██╔══██╗████╗ ████║██╔══██╗██╔════╝██╔════╝
 * ███████╗█████╗  ███████║██████╔╝███████╗██████╔╝██╔████╔██║███████║███████╗██║     
 * ╚════██║██╔══╝  ██╔══██║██╔══██╗╚════██║██╔══██╗██║╚██╔╝██║██╔══██║╚════██║██║     
 * ███████║███████╗██║  ██║██║  ██║███████║██║  ██║██║ ╚═╝ ██║██║  ██║███████║╚██████╗
 * ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝
 * 
 * ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
 * ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▄▄▄▄▄▄▄▄▄▄▄░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
 * ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▌░░░░░░░░░▌░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
 * ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▌░░░░░░░░░▌░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
 * ░░░░░░░░░░░░░░░░░░░░░░░░░▄▄▄▄▄▌░░░░░░░░░▐▄▄▄▄▄░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
 * ░░░░░░░░░░░░░░░░░░░░░░░░░▌░░░░░░░░░░░░░░░░░░░▐░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
 * ░░░░░░░░░░░░░░░░░░░░░░░░░▌░░░░░░░░░░░░░░░░░░░▐░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
 * ░░░░░░░░░░░░░░░░░░░░░░░░░▐░░░░░░░░░░░░░░░░░░░▌░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
 * ░░░░░░░░░░░░░░░░░░░░░░░░░░▐▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▌░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
 * ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
 * 
 * ╔═══════════════════════════════════════════════════════════════════════════════════╗
 * ║  THE FINEST GRAIN ERC1155a TOKEN                                                  ║
 * ║  ═══════════════════════════════════════════════════════════════════════════════   ║
 * ║                                                                                   ║
 * ║  LICENSE: PROPRIETARY - EXCLUSIVE PROPERTY OF ALBERT HUELLSTROUNK                 ║
 * ║  ═══════════════════════════════════════════════════════════════════════════════   ║
 * ║                                                                                   ║
 * ║  This token represents the world's finest grain - a legendary commodity           ║
 * ║  of unparalleled quality, purity, and prestige. Each token is a certificate      ║
 * ║  of authenticity for grain that has been:                                         ║
 * ║                                                                                   ║
 * ║  • Hand-selected from the most pristine harvests                                  ║
 * ║  • Verified through a 12-stage quality assurance process                          ║
 * ║  • Stored in climate-controlled vaults with biometric security                    ║
 * ║  • Traceable to its origin through immutable blockchain records                   ║
 * ║                                                                                   ║
 * ║  ═══════════════════════════════════════════════════════════════════════════════   ║
 * ║  LEGAL NOTICE:                                                                    ║
 * ║  This smart contract and all associated intellectual property is the              ║
 * ║  exclusive property of ALBERT HUELLSTROUNK. Any unauthorized copying,             ║
 * ║  modification, distribution, or use is strictly prohibited and will be            ║
 * ║  prosecuted to the fullest extent of the law.                                     ║
 * ║                                                                                   ║
 * ║  © 2024 Albert Huellstrounk. All Rights Reserved.                                 ║
 * ║  License ID: AH-FINEST-GRAIN-2024-EXCLUSIVE                                       ║
 * ╚═══════════════════════════════════════════════════════════════════════════════════╝
 */

pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC1155/ERC1155.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/security/Pausable.sol";
import "@openzeppelin/contracts/utils/Counters.sol";

/**
 * @title ERC1155a_FinestGrain
 * @author Albert Huellstrounk
 * @notice The world's most exclusive grain token with maximum security
 * @dev Enhanced ERC1155 with anti-theft measures and exclusive licensing
 */
contract ERC1155a_FinestGrain is ERC1155, AccessControl, Pausable {
    using Counters for Counters.Counter;

    // ═══════════════════════════════════════════════════════════════════════════
    // IMMUTABLE LICENSE DATA - CANNOT BE CHANGED AFTER DEPLOYMENT
    // ═══════════════════════════════════════════════════════════════════════════
    
    string public constant LICENSE_HOLDER = "ALBERT HUELLSTROUNK";
    string public constant LICENSE_ID = "AH-FINEST-GRAIN-2024-EXCLUSIVE";
    string public constant LICENSE_TYPE = "EXCLUSIVE_PERPETUAL_IRREVOCABLE";
    string public constant COPYRIGHT_YEAR = "2024";
    
    bytes32 public constant LICENSE_HASH = 
        0x416c626572744875656c6c7374726f756e6b46696e657374477261696e4c6963656e73;
    
    uint256 public immutable LICENSE_BLOCK;
    address public immutable LICENSE_HOLDER_ADDRESS;

    // ═══════════════════════════════════════════════════════════════════════════
    // ROLE DEFINITIONS
    // ═══════════════════════════════════════════════════════════════════════════
    
    bytes32 public constant LICENSE_HOLDER_ROLE = keccak256("LICENSE_HOLDER_ROLE");
    bytes32 public constant GRAIN_KEEPER_ROLE = keccak256("GRAIN_KEEPER_ROLE");
    bytes32 public constant SECURITY_OFFICER_ROLE = keccak256("SECURITY_OFFICER_ROLE");

    // ═══════════════════════════════════════════════════════════════════════════
    // TOKEN IDENTITIES - The Finest Grains of the World
    // ═══════════════════════════════════════════════════════════════════════════
    
    uint256 public constant IMPERIAL_GOLDEN_WHEAT = 1;
    uint256 public constant CELESTIAL_RICE = 2;
    uint256 public constant ROYAL_QUINOA = 3;
    uint256 public constant ANCESTRAL_BARLEY = 4;
    uint256 public constant MYSTICAL_AMARANTH = 5;
    uint256 public constant LEGENDARY_SPELT = 6;
    uint256 public constant SACRED_TEFF = 7;
    uint256 public constant DIVINE_MILLET = 8;

    // ═══════════════════════════════════════════════════════════════════════════
    // GRAIN CERTIFICATE STRUCTURE
    // ═══════════════════════════════════════════════════════════════════════════
    
    struct GrainCertificate {
        string grainType;
        string origin;
        uint256 harvestYear;
        uint256 purityScore;
        string qualityGrade;
        uint256 certificationDate;
        bytes32 certificationHash;
        bool isVerified;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // STATE VARIABLES
    // ═══════════════════════════════════════════════════════════════════════════
    
    mapping(uint256 => GrainCertificate) public grainCertificates;
    mapping(address => bool) private _transferWhitelist;
    mapping(address => bool) private _frozenAccounts;
    mapping(uint256 => uint256) private _totalSupply;
    mapping(uint256 => uint256) public maxSupply;
    
    string private _contractURI;
    Counters.Counter private _tokenIdCounter;

    // ═══════════════════════════════════════════════════════════════════════════
    // EVENTS
    // ═══════════════════════════════════════════════════════════════════════════
    
    event TransferWhitelistUpdated(address indexed account, bool status);
    event AccountFrozen(address indexed account, bool status);
    event EmergencyActionTaken(address indexed officer, string action);
    event GrainCertified(uint256 indexed tokenId, GrainCertificate certificate);
    event LicenseEnforced(string licenseId, string holder, uint256 timestamp);

    // ═══════════════════════════════════════════════════════════════════════════
    // ERRORS
    // ═══════════════════════════════════════════════════════════════════════════
    
    error TransferToNonWhitelistedAddress();
    error AccountIsFrozen();
    error ExceedsMaxSupply();
    error InvalidTokenId();

    // ═══════════════════════════════════════════════════════════════════════════
    // CONSTRUCTOR
    // ═══════════════════════════════════════════════════════════════════════════
    
    constructor(
        address licenseHolder,
        string memory baseUri,
        string memory contractUri
    ) ERC1155(baseUri) {
        // Store immutable license data
        LICENSE_BLOCK = block.number;
        LICENSE_HOLDER_ADDRESS = licenseHolder;
        
        // Grant all roles to the license holder
        _grantRole(DEFAULT_ADMIN_ROLE, licenseHolder);
        _grantRole(LICENSE_HOLDER_ROLE, licenseHolder);
        _grantRole(GRAIN_KEEPER_ROLE, licenseHolder);
        _grantRole(SECURITY_OFFICER_ROLE, licenseHolder);
        
        // Whitelist the license holder
        _transferWhitelist[licenseHolder] = true;
        
        // Set contract URI
        _contractURI = contractUri;
        
        // Initialize grain certificates
        _initializeGrainCertificates();
        
        // Set maximum supplies (extremely limited for exclusivity)
        maxSupply[IMPERIAL_GOLDEN_WHEAT] = 100;
        maxSupply[CELESTIAL_RICE] = 75;
        maxSupply[ROYAL_QUINOA] = 50;
        maxSupply[ANCESTRAL_BARLEY] = 60;
        maxSupply[MYSTICAL_AMARANTH] = 40;
        maxSupply[LEGENDARY_SPELT] = 30;
        maxSupply[SACRED_TEFF] = 25;
        maxSupply[DIVINE_MILLET] = 20;
        
        emit LicenseEnforced(LICENSE_ID, LICENSE_HOLDER, block.timestamp);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // GRAIN CERTIFICATE INITIALIZATION
    // ═══════════════════════════════════════════════════════════════════════════
    
    function _initializeGrainCertificates() internal {
        grainCertificates[IMPERIAL_GOLDEN_WHEAT] = GrainCertificate({
            grainType: "Imperial Golden Wheat",
            origin: "Ancient Fertile Crescent, Mesopotamia",
            harvestYear: 2024,
            purityScore: 9999,
            qualityGrade: "AAA",
            certificationDate: block.timestamp,
            certificationHash: keccak256(abi.encodePacked("IMPERIAL_GOLDEN_WHEAT", block.timestamp, "ALBERT_HUELLSTROUNK")),
            isVerified: true
        });
        
        grainCertificates[CELESTIAL_RICE] = GrainCertificate({
            grainType: "Celestial Rice",
            origin: "Philippine Cordillera Terraces, 2000m elevation",
            harvestYear: 2024,
            purityScore: 9997,
            qualityGrade: "AAA",
            certificationDate: block.timestamp,
            certificationHash: keccak256(abi.encodePacked("CELESTIAL_RICE", block.timestamp, "ALBERT_HUELLSTROUNK")),
            isVerified: true
        });
        
        grainCertificates[ROYAL_QUINOA] = GrainCertificate({
            grainType: "Royal Quinoa",
            origin: "Lake Titicaca Basin, Bolivia",
            harvestYear: 2024,
            purityScore: 9998,
            qualityGrade: "AAA",
            certificationDate: block.timestamp,
            certificationHash: keccak256(abi.encodePacked("ROYAL_QUINOA", block.timestamp, "ALBERT_HUELLSTROUNK")),
            isVerified: true
        });
        
        grainCertificates[ANCESTRAL_BARLEY] = GrainCertificate({
            grainType: "Ancestral Barley",
            origin: "Ethiopian Highlands, Ancient Teff Region",
            harvestYear: 2024,
            purityScore: 9995,
            qualityGrade: "AAA",
            certificationDate: block.timestamp,
            certificationHash: keccak256(abi.encodePacked("ANCESTRAL_BARLEY", block.timestamp, "ALBERT_HUELLSTROUNK")),
            isVerified: true
        });
        
        grainCertificates[MYSTICAL_AMARANTH] = GrainCertificate({
            grainType: "Mystical Amaranth",
            origin: "Valley of Mexico, Aztec Heritage Lands",
            harvestYear: 2024,
            purityScore: 9996,
            qualityGrade: "AAA",
            certificationDate: block.timestamp,
            certificationHash: keccak256(abi.encodePacked("MYSTICAL_AMARANTH", block.timestamp, "ALBERT_HUELLSTROUNK")),
            isVerified: true
        });
        
        grainCertificates[LEGENDARY_SPELT] = GrainCertificate({
            grainType: "Legendary Spelt",
            origin: "Swabian Alb, Southern Germany",
            harvestYear: 2024,
            purityScore: 9994,
            qualityGrade: "AAA",
            certificationDate: block.timestamp,
            certificationHash: keccak256(abi.encodePacked("LEGENDARY_SPELT", block.timestamp, "ALBERT_HUELLSTROUNK")),
            isVerified: true
        });
        
        grainCertificates[SACRED_TEFF] = GrainCertificate({
            grainType: "Sacred Teff",
            origin: "Ethiopian Highlands, Tigray Region",
            harvestYear: 2024,
            purityScore: 9993,
            qualityGrade: "AAA",
            certificationDate: block.timestamp,
            certificationHash: keccak256(abi.encodePacked("SACRED_TEFF", block.timestamp, "ALBERT_HUELLSTROUNK")),
            isVerified: true
        });
        
        grainCertificates[DIVINE_MILLET] = GrainCertificate({
            grainType: "Divine Millet",
            origin: "Hebei Province, China, Ancient Terraces",
            harvestYear: 2024,
            purityScore: 9992,
            qualityGrade: "AAA",
            certificationDate: block.timestamp,
            certificationHash: keccak256(abi.encodePacked("DIVINE_MILLET", block.timestamp, "ALBERT_HUELLSTROUNK")),
            isVerified: true
        });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ANTI-THEFT SECURITY FUNCTIONS
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * @dev Add address to transfer whitelist
     */
    function addToWhitelist(address account) external onlyRole(LICENSE_HOLDER_ROLE) {
        _transferWhitelist[account] = true;
        emit TransferWhitelistUpdated(account, true);
    }
    
    /**
     * @dev Remove address from transfer whitelist
     */
    function removeFromWhitelist(address account) external onlyRole(LICENSE_HOLDER_ROLE) {
        _transferWhitelist[account] = false;
        emit TransferWhitelistUpdated(account, false);
    }
    
    /**
     * @dev Check if address is whitelisted
     */
    function isWhitelisted(address account) external view returns (bool) {
        return _transferWhitelist[account];
    }
    
    /**
     * @dev Freeze an account
     */
    function freezeAccount(address account) external onlyRole(SECURITY_OFFICER_ROLE) {
        _frozenAccounts[account] = true;
        emit AccountFrozen(account, true);
        emit EmergencyActionTaken(msg.sender, "Account Frozen");
    }
    
    /**
     * @dev Unfreeze an account
     */
    function unfreezeAccount(address account) external onlyRole(LICENSE_HOLDER_ROLE) {
        _frozenAccounts[account] = false;
        emit AccountFrozen(account, false);
    }
    
    /**
     * @dev Check if account is frozen
     */
    function isFrozen(address account) external view returns (bool) {
        return _frozenAccounts[account];
    }
    
    /**
     * @dev Emergency pause all transfers
     */
    function emergencyPause() external onlyRole(SECURITY_OFFICER_ROLE) {
        _pause();
        emit EmergencyActionTaken(msg.sender, "Emergency Pause Activated");
    }
    
    /**
     * @dev Resume transfers
     */
    function resumeTransfers() external onlyRole(LICENSE_HOLDER_ROLE) {
        _unpause();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // MINTING FUNCTIONS
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * @dev Mint new tokens
     */
    function mint(
        address to,
        uint256 id,
        uint256 amount,
        bytes memory data
    ) external onlyRole(GRAIN_KEEPER_ROLE) {
        require(_transferWhitelist[to], "Recipient not whitelisted");
        require(_totalSupply[id] + amount <= maxSupply[id], "Exceeds max supply");
        
        _totalSupply[id] += amount;
        _mint(to, id, amount, data);
    }
    
    /**
     * @dev Batch mint tokens
     */
    function mintBatch(
        address to,
        uint256[] memory ids,
        uint256[] memory amounts,
        bytes memory data
    ) external onlyRole(GRAIN_KEEPER_ROLE) {
        require(_transferWhitelist[to], "Recipient not whitelisted");
        require(ids.length == amounts.length, "Length mismatch");
        
        for (uint256 i = 0; i < ids.length; ++i) {
            require(_totalSupply[ids[i]] + amounts[i] <= maxSupply[ids[i]], "Exceeds max supply");
            _totalSupply[ids[i]] += amounts[i];
        }
        
        _mintBatch(to, ids, amounts, data);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BURNING FUNCTIONS
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * @dev Burn tokens
     */
    function burn(address from, uint256 id, uint256 amount) external {
        require(from == msg.sender || isApprovedForAll(from, msg.sender), "Not authorized");
        require(!_frozenAccounts[from], "Account is frozen");
        
        _totalSupply[id] -= amount;
        _burn(from, id, amount);
    }
    
    /**
     * @dev Batch burn tokens
     */
    function burnBatch(address from, uint256[] memory ids, uint256[] memory amounts) external {
        require(from == msg.sender || isApprovedForAll(from, msg.sender), "Not authorized");
        require(!_frozenAccounts[from], "Account is frozen");
        require(ids.length == amounts.length, "Length mismatch");
        
        for (uint256 i = 0; i < ids.length; ++i) {
            _totalSupply[ids[i]] -= amounts[i];
        }
        
        _burnBatch(from, ids, amounts);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // OVERRIDDEN TRANSFER FUNCTIONS WITH SECURITY
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * @dev Override safeTransferFrom with security checks
     */
    function safeTransferFrom(
        address from,
        address to,
        uint256 id,
        uint256 amount,
        bytes memory data
    ) public override whenNotPaused {
        require(!_frozenAccounts[from], "Account is frozen");
        require(_transferWhitelist[to], "TransferToNonWhitelistedAddress");
        super.safeTransferFrom(from, to, id, amount, data);
    }
    
    /**
     * @dev Override safeBatchTransferFrom with security checks
     */
    function safeBatchTransferFrom(
        address from,
        address to,
        uint256[] memory ids,
        uint256[] memory amounts,
        bytes memory data
    ) public override whenNotPaused {
        require(!_frozenAccounts[from], "Account is frozen");
        require(_transferWhitelist[to], "TransferToNonWhitelistedAddress");
        super.safeBatchTransferFrom(from, to, ids, amounts, data);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // URI FUNCTIONS
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * @dev Get contract URI for OpenSea
     */
    function contractURI() external view returns (string memory) {
        return _contractURI;
    }
    
    /**
     * @dev Set contract URI
     */
    function setContractURI(string memory newUri) external onlyRole(LICENSE_HOLDER_ROLE) {
        _contractURI = newUri;
    }
    
    /**
     * @dev Set base URI
     */
    function setBaseURI(string memory newBaseURI) external onlyRole(LICENSE_HOLDER_ROLE) {
        _setURI(newBaseURI);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SUPPLY FUNCTIONS
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * @dev Get total supply of a token
     */
    function totalSupply(uint256 id) external view returns (uint256) {
        return _totalSupply[id];
    }
    
    /**
     * @dev Check if a token exists
     */
    function exists(uint256 id) external view returns (bool) {
        return _totalSupply[id] > 0;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // LICENSE VERIFICATION FUNCTIONS
    // ═══════════════════════════════════════════════════════════════════════════
    
    /**
     * @dev Get full license information
     */
    function getFullLicenseInfo() external pure returns (
        string memory holder,
        string memory licenseId,
        string memory licenseType,
        string memory copyright,
        string memory notice
    ) {
        return (
            "ALBERT HUELLSTROUNK",
            "AH-FINEST-GRAIN-2024-EXCLUSIVE",
            "EXCLUSIVE_PERPETUAL_IRREVOCABLE",
            "Copyright 2024 Albert Huellstrounk. All Rights Reserved.",
            "This smart contract and all associated intellectual property is the exclusive property of ALBERT HUELLSTROUNK. Any unauthorized copying, modification, distribution, or use is strictly prohibited."
        );
    }
    
    /**
     * @dev Verify a grain certificate
     */
    function verifyGrainCertificate(uint256 tokenId) external view returns (
        bool isValid,
        string memory grainType,
        string memory origin,
        uint256 purityScore
    ) {
        GrainCertificate memory cert = grainCertificates[tokenId];
        return (
            cert.isVerified && cert.certificationHash != bytes32(0),
            cert.grainType,
            cert.origin,
            cert.purityScore
        );
    }
    
    /**
     * @dev Supports interface
     */
    function supportsInterface(bytes4 interfaceId) public view override(ERC1155, AccessControl) returns (bool) {
        return super.supportsInterface(interfaceId);
    }
}