// ═══════════════════════════════════════════════════════════════════════════════
// THE FINEST GRAIN ERC1155a - DEPLOYMENT SCRIPT
// License: EXCLUSIVE PROPERTY OF ALBERT HUELLSTROUNK
// ═══════════════════════════════════════════════════════════════════════════════

const hre = require("hardhat");

async function main() {
  console.log("═══════════════════════════════════════════════════════════════════════");
  console.log("  THE FINEST GRAIN ERC1155a - DEPLOYMENT");
  console.log("  License: EXCLUSIVE PROPERTY OF ALBERT HUELLSTROUNK");
  console.log("═══════════════════════════════════════════════════════════════════════\n");

  // Get deployer account
  const [deployer] = await hre.ethers.getSigners();
  console.log("📦 Deploying contracts with account:", deployer.address);
  
  const balance = await hre.ethers.provider.getBalance(deployer.address);
  console.log("💰 Account balance:", hre.ethers.formatEther(balance), "ETH\n");

  // Configuration
  const LICENSE_HOLDER = process.env.LICENSE_HOLDER_ADDRESS || deployer.address;
  const BASE_URI = process.env.BASE_URI || "https://api.finestgrain.eth/metadata/";
  const CONTRACT_URI = process.env.CONTRACT_URI || "https://api.finestgrain.eth/contract.json";

  console.log("⚙️  Configuration:");
  console.log("   License Holder:", LICENSE_HOLDER);
  console.log("   Base URI:", BASE_URI);
  console.log("   Contract URI:", CONTRACT_URI, "\n");

  // Deploy the contract
  console.log("🚀 Deploying ERC1155a_FinestGrain...");
  
  const ERC1155a_FinestGrain = await hre.ethers.getContractFactory("ERC1155a_FinestGrain");
  const finestGrain = await ERC1155a_FinestGrain.deploy(
    LICENSE_HOLDER,
    BASE_URI,
    CONTRACT_URI
  );

  await finestGrain.waitForDeployment();
  const contractAddress = await finestGrain.getAddress();

  console.log("\n✅ ERC1155a_FinestGrain deployed to:", contractAddress);

  // Verify license information
  console.log("\n📋 License Information:");
  const licenseInfo = await finestGrain.getFullLicenseInfo();
  console.log("   Holder:", licenseInfo.holder);
  console.log("   License ID:", licenseInfo.licenseId);
  console.log("   Type:", licenseInfo.licenseType);

  // Display token information
  console.log("\n🌾 Token Types Available:");
  console.log("   ID 1: Imperial Golden Wheat (Max: 100)");
  console.log("   ID 2: Celestial Rice (Max: 75)");
  console.log("   ID 3: Royal Quinoa (Max: 50)");
  console.log("   ID 4: Ancestral Barley (Max: 60)");
  console.log("   ID 5: Mystical Amaranth (Max: 40)");
  console.log("   ID 6: Legendary Spelt (Max: 30)");
  console.log("   ID 7: Sacred Teff (Max: 25)");
  console.log("   ID 8: Divine Millet (Max: 20)");

  // Verification instructions
  console.log("\n📝 For contract verification, run:");
  console.log(`   npx hardhat verify --network ${hre.network.name} ${contractAddress} "${LICENSE_HOLDER}" "${BASE_URI}" "${CONTRACT_URI}"`);

  // Save deployment info
  const fs = require('fs');
  const deploymentInfo = {
    network: hre.network.name,
    contractAddress: contractAddress,
    licenseHolder: LICENSE_HOLDER,
    baseURI: BASE_URI,
    contractURI: CONTRACT_URI,
    deployer: deployer.address,
    deploymentTime: new Date().toISOString(),
    license: {
      holder: "ALBERT HUELLSTROUNK",
      licenseId: "AH-FINEST-GRAIN-2024-EXCLUSIVE",
      type: "EXCLUSIVE_PERPETUAL_IRREVOCABLE"
    }
  };

  const deploymentsDir = './deployments';
  if (!fs.existsSync(deploymentsDir)) {
    fs.mkdirSync(deploymentsDir);
  }
  
  fs.writeFileSync(
    `${deploymentsDir}/${hre.network.name}.json`,
    JSON.stringify(deploymentInfo, null, 2)
  );
  
  console.log(`\n💾 Deployment info saved to: deployments/${hre.network.name}.json`);
  console.log("\n═══════════════════════════════════════════════════════════════════════");
  console.log("  🎉 Deployment Complete!");
  console.log("  © 2024 Albert Huellstrounk. All Rights Reserved.");
  console.log("═══════════════════════════════════════════════════════════════════════");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("❌ Deployment failed:", error);
    process.exit(1);
  });